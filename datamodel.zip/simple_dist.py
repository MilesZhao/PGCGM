import torch
import numpy as np
from pymatgen.symmetry.groups import SpaceGroup

class sp_lookup:
    def __init__(self, device, sp_dict):
        self._affine_matrix_list = []
        self._affine_matrix_range = []
        self.device = device

        #mapping the heck
        d = {}
        for i in range(1,231):
            if i == 222:
                d['Pn-3n'] = i
                continue
            if i == 224:
                d['Pn-3m'] = i
                continue
            if i == 227:
                d['Fd-3m'] = i
                continue
            if i == 228:
                d['Fd-3c'] = i
                continue
            if i == 129:
                d['P4/nmm'] = i
                continue
            symbol = SpaceGroup.from_int_number(i).symbol
            if symbol.endswith("H"):
                symbol = symbol.replace("H", "")
            d[symbol] = i
        
        sp_list = []
        for symbol,i in sp_dict.items():
            sp_list.append((i, d[symbol], symbol))
        # exit(sp_list)
        for i,spid,_ in sp_list:
            symops = SpaceGroup.from_int_number(spid).symmetry_ops

            for op in symops:
                tmp = op.affine_matrix.astype(np.float32)
                
                if np.all(tmp == -1.0):
                    print(tmp)
                self._affine_matrix_list.append(tmp)
            
            self._affine_matrix_range.append((len(self._affine_matrix_list) - len(symops),\
             len(self._affine_matrix_list)))

    @property
    def affine_matrix_list(self):
        return torch.Tensor(self._affine_matrix_list).to(self.device)
    
    @property
    def affine_matrix_range(self):
        return torch.Tensor(self._affine_matrix_range).type(torch.int64).to(self.device)

    @property
    def symm_op_collection(self):
        arr = []
        for r0,r1 in self._affine_matrix_range:
            ops = np.array(self._affine_matrix_list)[r0:r1]
            zeros = np.zeros((192-len(ops), 4, 4))
            ops = np.concatenate((ops, zeros),0)
            arr.append(ops)
        arr = np.stack(arr, 0)

        return torch.Tensor(arr).type(torch.float32).to(self.device)

class DiffLattice(torch.nn.Module):
    def __init__(self, device):
        super().__init__()
        self.device = device
        self.pi = torch.acos(torch.zeros(1)).type(torch.float64).to(self.device)[0]/90.0

    def forward(self, a,b,c,alpha,beta,gamma):
        a = a.type(torch.float64)
        b = b.type(torch.float64)
        c = c.type(torch.float64)
        alpha = alpha.type(torch.float64)
        beta = beta.type(torch.float64)
        gamma = gamma.type(torch.float64)

        alpha, beta, gamma = alpha*self.pi, beta*self.pi, gamma*self.pi
        cos_alpha, cos_beta, cos_gamma = torch.cos(alpha), torch.cos(beta), torch.cos(gamma)
        sin_alpha, sin_beta, sin_gamma = torch.sin(alpha), torch.sin(beta), torch.sin(gamma)

        val = (cos_alpha * cos_beta - cos_gamma).to(self.device) / (sin_alpha * sin_beta).to(self.device)
        one = torch.ones(val.shape[0]).type(torch.float64).to(self.device)
        mone = -one
        val = torch.max(torch.min(val, one), mone)
        gamma_star = torch.acos(val)
        
        zero = torch.zeros(val.shape[0]).type(torch.float64).to(self.device) 
        vector_a = torch.stack((a*sin_beta, zero, a*cos_beta), -1)
        vector_b = torch.stack(
            [
                -b*sin_alpha * torch.cos(gamma_star),
                b * sin_alpha * torch.sin(gamma_star),
                b * cos_alpha
            ], -1)
        vector_c = torch.stack([zero, zero, c], -1)
        matrix = torch.stack((vector_a, vector_b, vector_c), 1).type(torch.float32)

        return matrix

class DiffDistMatrix(torch.nn.Module):

    def __init__(self, device):
        super().__init__()
        self.device = device
        self.epsilon = torch.tensor(1e-10).to(self.device)

    def forward(self, fcoords1, fcoords2, matrix):
        cart_coords = torch.einsum('sij,sjk->sik', fcoords1%1, matrix)
        cart_f1 = torch.einsum('sij,sjk->sik', fcoords1%1, matrix)
        cart_f2 = torch.einsum('sij,sjk->sik', fcoords2%1, matrix)
        cart_im = torch.einsum('ij,sjk->sik', self.images_view, matrix)

        I = fcoords1.shape[1]
        cart_f2 = cart_f2.unsqueeze_(2)
        cart_f2 = torch.repeat_interleave(cart_f2, repeats=I, dim=2)
        
        cart_f1 = cart_f1.unsqueeze_(1)
        cart_f1 = torch.repeat_interleave(cart_f1, repeats=I, dim=1)
        cart_f2 = cart_f2.sub_(cart_f1)
        cart_f2 = cart_f2.unsqueeze_(3) 
        cart_f2 = torch.repeat_interleave(cart_f2, repeats=27, dim=3)

        cart_im = cart_im.unsqueeze_(1)
        cart_im = torch.repeat_interleave(cart_im, repeats=I, dim=1)
        cart_im = cart_im.unsqueeze_(1)
        cart_im = torch.repeat_interleave(cart_im, repeats=I, dim=1)
        cart_f2 = cart_f2.add_(cart_im).pow_(2)
        cart_f2 = torch.sum(cart_f2, -1)
        dm,_ = torch.min(cart_f2, -1) 
        dm = dm + self.epsilon #numerical stability

        return torch.sqrt(dm),cart_coords

    @property
    def images_view(self):
        img = torch.tensor([
                       [-1., -1., -1.],
                       [-1., -1.,  0.],
                       [-1., -1.,  1.],
                       [-1.,  0., -1.],
                       [-1.,  0.,  0.],
                       [-1.,  0.,  1.],
                       [-1.,  1., -1.],
                       [-1.,  1.,  0.],
                       [-1.,  1.,  1.],
                       [ 0., -1., -1.],
                       [ 0., -1.,  0.],
                       [ 0., -1.,  1.],
                       [ 0.,  0., -1.],
                       [ 0.,  0.,  0.],
                       [ 0.,  0.,  1.],
                       [ 0.,  1., -1.],
                       [ 0.,  1.,  0.],
                       [ 0.,  1.,  1.],
                       [ 1., -1., -1.],
                       [ 1., -1.,  0.],
                       [ 1., -1.,  1.],
                       [ 1.,  0., -1.],
                       [ 1.,  0.,  0.],
                       [ 1.,  0.,  1.],
                       [ 1.,  1., -1.],
                       [ 1.,  1.,  0.],
                       [ 1.,  1.,  1.]
                       ]
                    )
        return img.to(self.device)

def calc_volume(matrix):
    cross = torch.cross(matrix[:,0,:], matrix[:,1,:])
    vol = torch.einsum('ij,ij->i',cross, matrix[:,2,:])
    return torch.abs(vol)
